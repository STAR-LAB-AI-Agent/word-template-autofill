"""test_wt.py —— 核心引擎与 CLI 的自动化测试。

运行：  cd word-template-filler && python -m pytest tests/ -v
覆盖：正常输入、边界情况、异常与安全。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from docx import Document

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "skills" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from wt_core import (  # noqa: E402
    MissingFieldError, PathNotAllowedError, escape_value, fill_document,
    resolve_in_workspace, scan_template,
)


def sample(kind: str) -> str:
    """返回示例文件的相对路径，优先用规范名，其次 glob 兜底。

    Windows 解压中文 zip 可能把文件名解成乱码（UTF-8 字节按 GBK 解码失败），
    所以：先找规范名（conftest 会确保它存在），找不到再按扩展名兜底。
    """
    canonical = {"template": "templates/实习协议模板.docx",
                 "data": "data/实习生名单.xlsx"}
    if kind in canonical and (ROOT / canonical[kind]).exists():
        return canonical[kind]

    pats = {"template": "templates/*.docx", "data": "data/*.xlsx",
            "json": "data/*.json"}
    files = sorted(ROOT.glob(pats[kind]))
    if not files:
        pytest.skip(f"未找到示例文件（{pats[kind]}），跳过该用例")
    return str(files[0].relative_to(ROOT))


# ---------------------------------------------------------------- fixtures


@pytest.fixture
def tpl(tmp_path: Path) -> Path:
    """一个含拆-run 占位符 + 表格循环区的测试模板。"""
    doc = Document()
    p = doc.add_paragraph()
    p.add_run("甲方：{{公司")      # 故意拆 run
    p.add_run("名称}}")
    p.add_run("  乙方：{{姓名}}")
    doc.add_paragraph("岗位：{{岗位}}")
    doc.sections[0].header.paragraphs[0].text = "页眉-{{公司名称}}"

    tbl = doc.add_table(rows=2, cols=3)
    tbl.rows[0].cells[0].text = "序号"
    tbl.rows[0].cells[1].text = "课程"
    tbl.rows[0].cells[2].text = "课时"
    r = tbl.rows[1].cells
    r[0].text = "{{#items}}{{index}}"
    r[1].text = "{{课程}}"
    r[2].text = "{{课时}}"

    path = tmp_path / "tpl.docx"
    doc.save(str(path))
    return path


def run_cli(*args: str) -> dict:
    """运行 CLI 并解析 JSON 输出（Windows / Linux 双平台稳健版）。

    三个关键处理：
      1. 强制子进程用 UTF-8（-X utf8 + PYTHONUTF8）——中文 Windows 默认 GBK，
         脚本 ensure_ascii=False 输出的中文会被父进程按 UTF-8 解码而炸掉。
      2. 用显式 PIPE + 字节模式，自己解码（errors="replace"）——不依赖
         text=True，也避免 stdout 为 None 时 AttributeError。
      3. 无输出时给出完整诊断（命令 / 返回码 / stderr），而不是干巴巴地报错。
    """
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    cmd = [sys.executable, "-X", "utf8", str(SCRIPTS / args[0]),
           *(str(a) for a in args[1:]), "--json"]

    proc = subprocess.run(
        cmd, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)

    raw_out = proc.stdout or b""
    raw_err = proc.stderr or b""
    out = raw_out.decode("utf-8", errors="replace").strip()

    if not out:
        detail = raw_err.decode("utf-8", errors="replace").strip()
        pytest.fail(
            "CLI 无 JSON 输出\n"
            f"  命令:   {' '.join(cmd)}\n"
            f"  返回码: {proc.returncode}\n"
            f"  stdout: {out!r}\n"
            f"  stderr: {detail[:800]}")
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        pytest.fail(f"CLI 输出不是合法 JSON：{out[:300]}")


def text_of(path: Path) -> str:
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs)


# ---------------------------------------------------------------- 正常路径


def test_split_run_placeholder_replaced(tpl: Path, tmp_path: Path):
    """核心坑：{{公司名称}} 被拆进两个 run，必须仍能替换。"""
    out = tmp_path / "a.docx"
    fill_document(tpl, {"公司名称": "深空科技", "姓名": "张伟", "岗位": "安服"}, out)
    assert "甲方：深空科技" in text_of(out)


def test_header_placeholder_replaced(tpl: Path, tmp_path: Path):
    """页眉页脚属于非正文区域，同样要覆盖。"""
    out = tmp_path / "h.docx"
    fill_document(tpl, {"公司名称": "星环", "姓名": "李娜", "岗位": "研发"}, out)
    assert Document(str(out)).sections[0].header.paragraphs[0].text == "页眉-星环"


def test_loop_rows_expanded(tpl: Path, tmp_path: Path):
    """表格循环区按数据条数展开，index 自动编号。"""
    out = tmp_path / "l.docx"
    fill_document(tpl, {"公司名称": "A", "姓名": "B", "岗位": "C", "items": [
        {"课程": "恶意流量", "课时": "16"},
        {"课程": "应急响应", "课时": "12"},
    ]}, out)
    tbl = Document(str(out)).tables[0]
    assert len(tbl.rows) == 3                       # 表头 + 2 条明细
    assert tbl.rows[1].cells[1].text == "恶意流量"
    assert tbl.rows[2].cells[0].text == "2"         # 自动序号


def test_loop_removed_when_no_data(tpl: Path, tmp_path: Path):
    """边界：明细为空时删除模板行，不留空行幽灵。"""
    out = tmp_path / "e.docx"
    fill_document(tpl, {"公司名称": "A", "姓名": "B", "岗位": "C"}, out)
    assert len(Document(str(out)).tables[0].rows) == 1   # 只剩表头


# ---------------------------------------------------------------- 缺失字段三策略


def test_lenient_fills_missing_mark(tpl: Path, tmp_path: Path):
    out = tmp_path / "m.docx"
    fill_document(tpl, {"公司名称": "A", "姓名": "B"}, out, mode="lenient")
    assert "【待补充】" in text_of(out)


def test_strict_raises_on_missing(tpl: Path, tmp_path: Path):
    with pytest.raises(MissingFieldError) as e:
        fill_document(tpl, {"公司名称": "A", "姓名": "B"}, tmp_path / "s.docx",
                      mode="strict")
    assert "岗位" in str(e.value)


def test_default_map_applied(tpl: Path, tmp_path: Path):
    out = tmp_path / "d.docx"
    fill_document(tpl, {"公司名称": "A", "姓名": "B"}, out, mode="default",
                  default_map={"岗位": "待定岗位"})
    assert "岗位：待定岗位" in text_of(out)


# ---------------------------------------------------------------- 安全


def test_template_injection_is_escaped(tpl: Path, tmp_path: Path):
    """数据里的 {{...}} 必须被转义，不能被二次渲染。"""
    out = tmp_path / "i.docx"
    fill_document(tpl, {"公司名称": "{{岗位}}", "姓名": "X", "岗位": "Y"}, out)
    assert "{{岗位}}" not in text_of(out)
    assert "｛｛岗位｝｝" in text_of(out)


def test_escape_value_helper():
    assert escape_value("{{a}}") == "｛｛a｝｝"
    assert escape_value(None) == ""


def test_path_traversal_blocked(tmp_path: Path):
    with pytest.raises(PathNotAllowedError):
        resolve_in_workspace(tmp_path, "../../etc/passwd")


def test_cli_rejects_outside_data():
    """CLI 层同样拦截越界路径。"""
    r = run_cli("fill_template.py", "--root", ".", "--template",
                sample("template"), "--data", "../../../etc/passwd",
                "--out", "output")
    assert r["success"] is False
    assert "路径越界" in r["failed"][0]["error"]


# ---------------------------------------------------------------- 扫描与 CLI


def test_scan_template_lists_fields_and_loops(tpl: Path):
    info = scan_template(tpl)
    names = {f["field"] for f in info["fields"]}
    assert {"公司名称", "姓名", "岗位"} <= names
    assert [l["name"] for l in info["loops"]] == ["items"]
    assert set(info["loop_fields"]) == {"课程", "课时"}   # index 为自动字段


def test_cli_inspect_and_validate_and_fill():
    """端到端：扫描 → 体检 → 批量填充（使用仓库自带示例数据）。"""
    tpl_rel, data_rel = sample("template"), sample("data")

    info = run_cli("inspect_template.py", "--root", ".", "--template", tpl_rel)
    assert info["success"] and info["counts"]["fields"] >= 10

    rep = run_cli("validate_data.py", "--root", ".", "--template", tpl_rel,
                  "--data", data_rel)
    assert rep["total_records"] == 4
    assert rep["ok_records"] == 3

    res = run_cli("fill_template.py", "--root", ".", "--template", tpl_rel,
                  "--data", data_rel, "--out", "output",
                  "--out-name", "T_{姓名}.docx", "--overwrite")
    assert res["success"] and res["stats"]["generated"] == 4

    # 低 Token：返回值里不含文档正文
    assert "实习协议书" not in json.dumps(res, ensure_ascii=False)


def test_cli_dry_run_writes_nothing():
    """dry-run 只预览，不得落盘。"""
    res = run_cli("fill_template.py", "--root", ".", "--template",
                  sample("template"), "--data", sample("data"),
                  "--out", "output", "--out-name", "DRY_{姓名}.docx", "--dry-run")
    assert res["stats"]["dry_run"] is True
    assert res["output_files"] == []
    assert not any((ROOT / "output").glob("DRY_*.docx"))


def test_cli_rejects_non_docx_template():
    res = run_cli("fill_template.py", "--root", ".", "--template",
                  sample("data"), "--data", sample("data"),
                  "--out", "output")
    assert res["success"] is False


def test_cli_row_out_of_range():
    res = run_cli("fill_template.py", "--root", ".", "--template",
                  sample("template"), "--data", sample("data"),
                  "--out", "output", "--row", 99)
    assert res["success"] is False
    assert "超出范围" in res["failed"][0]["error"]
