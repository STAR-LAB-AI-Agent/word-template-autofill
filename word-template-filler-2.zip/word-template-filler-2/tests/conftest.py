"""conftest.py —— pytest 公共夹具。

做一件事：确保示例文件（模板 + 数据）存在。

为什么需要：zip 包里的中文文件名在 Windows 上用系统自带工具解压时，
UTF-8 字节按 GBK 解码会失败（illegal multibyte sequence），文件名变成乱码，
导致依赖文件名的用例被跳过。这里在测试开始前检查，缺失就调用
make_samples.py 现场生成——由 Python 直接写盘，文件名一定正确。
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent

# 规范文件名（make_samples.py 生成的就是这两个）
CANONICAL = {
    "template": "templates/实习协议模板.docx",
    "data": "data/实习生名单.xlsx",
}


@pytest.fixture(scope="session", autouse=True)
def ensure_samples():
    """会话级、自动生效：缺示例文件就先生成，再跑用例。"""
    missing = [rel for rel in CANONICAL.values() if not (ROOT / rel).exists()]
    if not missing:
        return

    proc = subprocess.run(
        [sys.executable, str(ROOT / "skills" / "scripts" / "make_samples.py")],
        cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=180)

    still = [rel for rel in CANONICAL.values() if not (ROOT / rel).exists()]
    if still:
        pytest.exit(
            "示例文件缺失，且自动生成失败。\n"
            f"  缺少：{still}\n"
            f"  生成脚本返回码：{proc.returncode}\n"
            f"  stderr：{(proc.stderr or '').strip()[:500]}",
            returncode=1)
