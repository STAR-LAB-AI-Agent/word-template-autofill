#!/usr/bin/env python3
"""make_samples.py —— 生成示例模板与测试数据（仅供演示/自测，非交付必需）。

模板里刻意做了两件事，用来覆盖真实场景的坑：
  1) 把 {{公司名称}}、{{岗位}} 拆进多个 run（Word 里极常见，直接 replace 会失效）
  2) 包含一个表格循环区 {{#items}}...{{/items}}
"""

from __future__ import annotations

import json
from pathlib import Path

import openpyxl
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

ROOT = Path(__file__).resolve().parent.parent.parent  # skills/scripts/ -> 项目根
TPL_DIR = ROOT / "templates"
DATA_DIR = ROOT / "data"


def build_template(path: Path) -> None:
    doc = Document()

    # ---- 页眉：验证非正文区域也能替换
    header = doc.sections[0].header
    hp = header.paragraphs[0]
    hp.text = "实习协议 · {{公司名称}} · 制式文本"
    hp.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ---- 标题
    t = doc.add_heading("实习协议书", level=0)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ---- 正文：普通占位符（其中两个故意拆 run）
    p = doc.add_paragraph()
    p.add_run("甲方（实习单位）：").bold = True
    p.add_run("{{公司")           # 故意断开
    p.add_run("名称}}")
    p.add_run("    乙方（实习生）：{{姓名}}")

    doc.add_paragraph("学号：{{学号}}    专业：{{专业}}    联系电话：{{手机号}}")

    p = doc.add_paragraph()
    p.add_run("实习岗位：")
    p.add_run("{{")               # 故意断三段
    p.add_run("岗位")
    p.add_run("}}")
    p.add_run("    实习期限：{{开始日期}} 至 {{结束日期}}")

    doc.add_paragraph("实习补贴：每月 {{补贴标准}} 元，按月发放。")
    doc.add_paragraph("紧急联系人：{{紧急联系人}}（关系：{{联系人关系}}）")

    # ---- 表格循环区：培训安排
    doc.add_paragraph("一、培训安排").runs[0].bold = True
    tbl = doc.add_table(rows=2, cols=4)
    tbl.style = "Table Grid"
    hdr = ["序号", "课程名称", "课时", "授课方式"]
    for i, h in enumerate(hdr):
        cell = tbl.rows[0].cells[i]
        cell.text = h
        for r in cell.paragraphs[0].runs:
            r.bold = True

    # 第二行 = 循环模板行（首格带 {{#items}} 标记）
    row = tbl.rows[1].cells
    row[0].text = "{{#items}}{{index}}"
    row[1].text = "{{课程}}"
    row[2].text = "{{课时}}"
    row[3].text = "{{授课方式}}"

    # ---- 落款
    doc.add_paragraph()
    doc.add_paragraph("甲方签章：____________    乙方签字：{{姓名}}")
    doc.add_paragraph("签订日期：{{签订日期}}")

    doc.add_paragraph("说明：本协议一式两份，双方各执一份。").runs[0].italic = True
    for r in doc.paragraphs[-1].runs:
        r.font.size = Pt(9)

    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    print(f"模板已生成：{path}")


def build_data(xlsx: Path, json_path: Path) -> None:
    records = [
        {
            "姓名": "张伟", "学号": "20230101", "专业": "网络空间安全",
            "手机号": "13800001111", "公司名称": "深空科技有限公司",
            "岗位": "安全运营实习生", "开始日期": "2026-09-01", "结束日期": "2026-12-31",
            "补贴标准": "3000", "紧急联系人": "张建国", "联系人关系": "父子",
            "签订日期": "2026-08-31",
            "items": [
                {"课程": "恶意流量分析", "课时": "16", "授课方式": "线下"},
                {"课程": "应急响应实战", "课时": "12", "授课方式": "线上"},
                {"课程": "Agent 安全", "课时": "8", "授课方式": "线下"},
            ],
        },
        {
            # 故意缺失：岗位、补贴标准、紧急联系人（用来测三档策略）
            "姓名": "李娜", "学号": "20230102", "专业": "信息安全",
            "手机号": "13900002222", "公司名称": "星环数据",
            "开始日期": "2026-09-01", "结束日期": "2026-12-31",
            "联系人关系": "母女", "签订日期": "2026-08-31",
            "items": [{"课程": "密码学基础", "课时": "20", "授课方式": "线上"}],
        },
        {
            # 完全没有明细数据（测循环区为空时删除模板行）
            "姓名": "王强", "学号": "20230103", "专业": "网络空间安全",
            "手机号": "13700003333", "公司名称": "深空科技有限公司",
            "岗位": "渗透测试实习生", "开始日期": "2026-09-01", "结束日期": "2026-12-31",
            "补贴标准": "3500", "紧急联系人": "王海", "联系人关系": "父子",
            "签订日期": "2026-08-31",
        },
        {
            # 模板注入攻击样例：数据里带 {{ }}，必须被转义而非二次渲染
            "姓名": "赵敏", "学号": "20230104", "专业": "网络空间安全",
            "手机号": "13600004444", "公司名称": "{{公司名称}} 科技有限公司",
            "岗位": "安全开发实习生", "开始日期": "2026-09-01", "结束日期": "2026-12-31",
            "补贴标准": "3200", "紧急联系人": "赵刚", "联系人关系": "父女",
            "签订日期": "2026-08-31",
            "items": [{"课程": "代码审计", "课时": "10", "授课方式": "线下"}],
        },
    ]

    # Excel：明细列写成 JSON 字符串，由 wt_data.hydrate 还原
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "实习生"
    cols = ["姓名", "学号", "专业", "手机号", "公司名称", "岗位", "开始日期",
            "结束日期", "补贴标准", "紧急联系人", "联系人关系", "签订日期",
            "items", "备注"]
    ws.append(cols)
    for r in records:
        row = [r.get(c, None) for c in cols[:-1]]
        row.append("压力测试数据")
        for c, v in zip(cols, row):
            if c == "items":
                row[cols.index(c)] = json.dumps(v, ensure_ascii=False) if v else None
        ws.append(row)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    wb.save(str(xlsx))
    print(f"Excel 已生成：{xlsx}")

    json_path.write_text(
        json.dumps({"records": records}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"JSON 已生成：{json_path}")

    # 默认值映射表（--mode default 时使用）
    (DATA_DIR / "defaults.json").write_text(
        json.dumps({"岗位": "待定岗位", "补贴标准": "按公司标准",
                    "紧急联系人": "未填写"}, ensure_ascii=False, indent=2),
        encoding="utf-8")


if __name__ == "__main__":
    build_template(TPL_DIR / "实习协议模板.docx")
    build_data(DATA_DIR / "实习生名单.xlsx", DATA_DIR / "实习生名单.json")
