#!/usr/bin/env python3
"""check_env.py —— 环境自检：确认 Python 版本、依赖、目录与 CLI 是否就绪。

运行：  python skills/scripts/check_env.py
全绿即环境配置完成，可以开始使用。
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent  # skills/scripts/ -> 项目根
OK, WARN, FAIL = "[OK]  ", "[WARN]", "[FAIL]"


def check(label: str, ok: bool, detail: str = "", fatal: bool = False) -> bool:
    print(f"{(OK if ok else (FAIL if fatal else WARN))} {label}"
          + (f"  -> {detail}" if detail else ""))
    return ok


def main() -> int:
    print("=" * 60)
    print("AI Word 模板填充 · 环境自检")
    print("=" * 60)

    # 1. Python 版本
    v = sys.version_info
    ver = f"{v.major}.{v.minor}.{v.micro}"
    ok_py = (3, 10) <= (v.major, v.minor) <= (3, 12)
    check(f"Python 版本 {ver}", ok_py,
          "" if ok_py else "需要 3.10~3.12（本项目未用到更高版本特性，3.13 通常也能跑）")
    print(f"       解释器路径：{sys.executable}")

    # 2. 是否在虚拟环境内（可选，不强制）
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    check("运行环境", True, "虚拟环境(.venv)" if in_venv else "全局 Python（未使用虚拟环境，可直接运行）")

    # 3. 依赖
    print("\n--- 依赖检查 ---")
    # 运行时必需
    missing = []
    for mod, pkg in {"docx": "python-docx", "openpyxl": "openpyxl"}.items():
        try:
            m = __import__(mod)
            print(f"{OK} {pkg:<14} {getattr(m, '__version__', '已安装')}")
        except ImportError:
            print(f"{FAIL} {pkg:<14} 未安装（运行时必需）  -> pip install {pkg}")
            missing.append(pkg)

    # 仅测试需要，缺失不阻塞使用
    try:
        import pytest  # noqa: F401
        print(f"{OK} {'pytest':<14} {pytest.__version__}")
    except ImportError:
        print(f"{WARN} {'pytest':<14} 未安装（仅跑测试需要）  -> pip install pytest")

    # 4. 目录与关键文件
    print("\n--- 目录与文件 ---")
    for d in ("skills/SKILL.md", "skills/scripts", "templates", "data", "output", "logs"):
        p = ROOT / d
        check(f"{d}", p.exists(), "" if p.exists() else "缺失，请确认完整解压")

    tpls = sorted((ROOT / "templates").glob("*.docx"))
    check("Word 模板", bool(tpls),
          f"找到 {len(tpls)} 个：{', '.join(t.name for t in tpls[:3])}" if tpls
          else "templates/ 下没有 .docx，请先放入模板")

    datas = sorted(list((ROOT / "data").glob("*.xlsx")) + list((ROOT / "data").glob("*.json")))
    check("数据文件", bool(datas),
          f"找到 {len(datas)} 个：{', '.join(d.name for d in datas[:3])}" if datas
          else "data/ 下没有 xlsx/json，请先放入数据")

    # 5. CLI 冒烟测试
    print("\n--- CLI 冒烟测试 ---")
    if tpls and not missing:
        py = sys.executable
        try:
            r = subprocess.run([py, str(ROOT / "skills" / "scripts" / "inspect_template.py"),
                                "--root", ".", "--template",
                                str(tpls[0].relative_to(ROOT)), "--json"],
                               cwd=ROOT, capture_output=True, text=True,
                               encoding="utf-8", timeout=60)
            check("inspect_template.py 可运行", r.returncode == 0,
                  (r.stdout.strip()[:80] if r.returncode == 0
                   else (r.stderr.strip()[:200] or "无输出")))
        except Exception as e:
            check("inspect_template.py 可运行", False, str(e))
    else:
        print(f"{WARN} 跳过（模板缺失或依赖未装齐）")

    # 6. 结论
    print("\n" + "=" * 60)
    if missing:
        print(f"缺少依赖，请执行：\n    {sys.executable} -m pip install -r requirements.txt")
        return 1
    if not ok_py:
        print("Python 版本不在推荐范围，但通常可继续；如运行报错请换 3.10~3.12。")
    print("环境就绪。下一步：")
    print("  1) python skills/scripts/inspect_template.py --root . --template templates/<你的模板>.docx")
    print("  2) python skills/scripts/validate_data.py --root . --template <模板> --data <数据>")
    print("  3) python skills/scripts/fill_template.py --root . --template <模板> --data <数据> "
          "--out output --dry-run")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
