#!/usr/bin/env python3
"""inspect_template.py —— 意图 1：这个模板要填哪些字段？

用法：
    python skills/scripts/inspect_template.py --template templates/合同模板.docx
    python skills/scripts/inspect_template.py --template templates/合同模板.docx --json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from wt_core import resolve_in_workspace, scan_template, setup_logger, TemplateFillError  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="扫描 Word 模板中的占位符与循环区")
    ap.add_argument("--template", required=True, help="docx 模板路径（相对项目根）")
    ap.add_argument("--root", default=".", help="工作区根目录（白名单边界）")
    ap.add_argument("--json", action="store_true", help="输出 JSON（供智能体解析）")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    setup_logger(verbose=args.verbose)
    try:
        root = Path(args.root).resolve()
        tpl = resolve_in_workspace(root, args.template)
        info = scan_template(tpl)
    except TemplateFillError as e:
        print(json.dumps({"success": False, "error": str(e)}, ensure_ascii=False))
        return 1

    if args.json:
        print(json.dumps({"success": True, **info}, ensure_ascii=False, indent=2))
        return 0

    print(f"模板：{info['template']}")
    print(f"\n普通字段（{info['counts']['fields']} 个）：")
    for f in info["fields"]:
        print(f"  {f['placeholder']:<24} 位置：{f['location']}")
    if info["loops"]:
        print(f"\n循环区（{info['counts']['loops']} 处）：")
        for l in info["loops"]:
            print(f"  {{{{#{l['name']}}}}}  位置：{l['location']}")
        print(f"  循环内字段：{', '.join(info['loop_fields']) or '（无）'}")
    if not info["fields"] and not info["loops"]:
        print("  未发现任何占位符，请确认模板使用 {{字段名}} 语法。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
