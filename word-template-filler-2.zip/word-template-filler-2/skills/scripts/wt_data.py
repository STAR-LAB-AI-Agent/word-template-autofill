"""wt_data.py —— 结构化数据加载（Excel / JSON / CSV）。

统一输出 list[dict]；空值（None / 空串 / 纯空白）归一为缺失，交给上层策略处理。
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from wt_core import TemplateFillError


def _is_missing(v) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def load_records(path: Path, sheet: str | None = None) -> list[dict]:
    """加载记录列表。空单元格保留为 None，由填充策略决定如何呈现。"""
    path = Path(path)
    if not path.exists():
        raise TemplateFillError(f"数据文件不存在：{path}")

    suffix = path.suffix.lower()

    if suffix in {".xlsx", ".xlsm"}:
        return _load_excel(path, sheet)
    if suffix == ".json":
        return _load_json(path)
    if suffix in {".csv", ".tsv"}:
        return _load_csv(path, suffix)
    raise TemplateFillError(f"暂不支持的数据格式：{suffix}（支持 xlsx/json/csv）")


def _load_excel(path: Path, sheet: str | None) -> list[dict]:
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb[sheet] if sheet else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        raise TemplateFillError(f"工作表为空：{path}")
    headers = [("" if h is None else str(h).strip()) for h in rows[0]]
    records = []
    for r in rows[1:]:
        if all(_is_missing(v) for v in r):
            continue  # 跳过整行空白
        rec = {}
        for h, v in zip(headers, r):
            if not h:
                continue
            rec[h] = None if _is_missing(v) else v
        records.append(rec)
    return records


def _load_json(path: Path) -> list[dict]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict):
        raw = raw.get("records", raw.get("data", [raw]))
    if not isinstance(raw, list):
        raise TemplateFillError("JSON 顶层应为数组，或含 records/data 字段")
    out = []
    for item in raw:
        if not isinstance(item, dict):
            raise TemplateFillError("JSON 数组元素应为对象")
        out.append({k: (None if _is_missing(v) else v) for k, v in item.items()})
    return out


def _load_csv(path: Path, suffix: str) -> list[dict]:
    delim = "\t" if suffix == ".tsv" else ","
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=delim)
        return [{k: (None if _is_missing(v) else v) for k, v in row.items()} for row in reader]


def list_sheets(path: Path) -> list[str]:
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    names = wb.sheetnames
    wb.close()
    return names


def normalize(record: dict) -> dict:
    """把记录里的空值剔除，方便判断"真实缺失"。"""
    return {k: v for k, v in record.items() if not _is_missing(v)}


def missing_fields_of(record: dict) -> list[str]:
    return [k for k, v in record.items() if _is_missing(v)]


def hydrate(record: dict) -> dict:
    """把形如 '[{"name":"A"}]' 的字符串自动还原成结构化数据。

    这样即使数据源是平面的 Excel，也能表达"明细表"这类嵌套循环字段。
    """
    out = {}
    for k, v in record.items():
        if isinstance(v, str):
            s = v.strip()
            if s.startswith(("[", "{")):
                try:
                    out[k] = json.loads(s)
                    continue
                except json.JSONDecodeError:
                    pass
        out[k] = v
    return out


def hydrate_all(records: list[dict]) -> list[dict]:
    return [hydrate(r) for r in records]
