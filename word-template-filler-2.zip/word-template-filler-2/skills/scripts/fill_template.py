#!/usr/bin/env python3
"""fill_template.py —— 意图 2：用 Excel/JSON 数据批量填充 Word 模板。

用法：
    # 先预览（不写盘）
    python skills/scripts/fill_template.py --template templates/合同模板.docx \
        --data data/员工.xlsx --out output --out-name "{姓名}_合同.docx" --dry-run

    # 正式批量生成
    python skills/scripts/fill_template.py --template templates/合同模板.docx \
        --data data/员工.xlsx --out output --out-name "{姓名}_合同.docx"

    # 只补第 3 条
    python skills/scripts/fill_template.py --template templates/合同模板.docx \
        --data data/员工.xlsx --out output --row 3

策略：--mode strict(缺字段中止) / lenient(填【待补充】,默认) / default(用默认值表)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from wt_core import (  # noqa: E402
    FillResult, fill_document, log_record_summary, resolve_in_workspace,
    scan_template, setup_logger, TemplateFillError,
)
from wt_data import hydrate_all, load_records  # noqa: E402

UNSAFE_NAME_CHARS = re.compile(r'[\\/:*?"<>|\r\n\t{}]')


def safe_filename(name: str, index: int, ext: str = ".docx") -> str:
    cleaned = UNSAFE_NAME_CHARS.sub("_", str(name)).strip().strip(".")
    cleaned = cleaned[:80] or f"record_{index}"
    if not cleaned.lower().endswith(ext):
        cleaned += ext
    return cleaned


def build_out_name(pattern: str | None, record: dict, index: int) -> str:
    if not pattern:
        keys = [k for k in ("姓名", "name", "名称", "编号", "id") if k in record]
        base = str(record.get(keys[0], f"record_{index}")) if keys else f"record_{index}"
        return safe_filename(base, index)
    try:
        return safe_filename(pattern.format(**{k: ("" if v is None else v)
                                               for k, v in record.items()}), index)
    except KeyError as e:
        return safe_filename(f"record_{index}_缺失字段{str(e)}", index)


def main() -> int:
    ap = argparse.ArgumentParser(description="批量把结构化数据填入 Word 模板")
    ap.add_argument("--template", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="output", help="输出目录（须在工作区内）")
    ap.add_argument("--out-name", default=None, help='命名模板，如 "{姓名}_合同.docx"')
    ap.add_argument("--sheet", default=None)
    ap.add_argument("--row", type=int, default=None, help="只处理第 N 条记录（1 开始）")
    ap.add_argument("--mode", choices=["strict", "lenient", "default"], default="lenient")
    ap.add_argument("--default-map", default=None, help="默认值：JSON 字符串或 .json 文件路径")
    ap.add_argument("--missing-mark", default="【待补充】")
    ap.add_argument("--dry-run", action="store_true", help="只预览不写盘")
    ap.add_argument("--overwrite", action="store_true", help="允许覆盖已存在文件")
    ap.add_argument("--root", default=".")
    ap.add_argument("--log", default="logs/fill.log")
    ap.add_argument("--json", action="store_true", help="输出 JSON（智能体默认走这个）")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    setup_logger(Path(args.root) / args.log if args.log else None, args.verbose)
    result = FillResult(success=True)

    try:
        root = Path(args.root).resolve()
        tpl = resolve_in_workspace(root, args.template)
        data = resolve_in_workspace(root, args.data)
        out_dir = resolve_in_workspace(root, args.out)

        if not tpl.exists():
            raise TemplateFillError(f"模板不存在：{tpl}")
        if tpl.suffix.lower() != ".docx":
            raise TemplateFillError(f"模板须为 .docx：{tpl}")

        default_map = {}
        if args.default_map:
            dm_path = Path(args.default_map)
            if dm_path.exists() and dm_path.suffix == ".json":
                default_map = json.loads(dm_path.read_text(encoding="utf-8"))
            else:
                default_map = json.loads(args.default_map)

        records = hydrate_all(load_records(data, args.sheet))
        if not records:
            raise TemplateFillError("数据文件中没有有效记录")

        if args.row is not None:
            if not (1 <= args.row <= len(records)):
                raise TemplateFillError(f"--row {args.row} 超出范围（共 {len(records)} 条）")
            records = [records[args.row - 1]]
            idx_offset = args.row - 1
        else:
            idx_offset = 0

        tpl_info = scan_template(tpl)
        if not tpl_info["fields"] and not tpl_info["loops"]:
            result.warnings.append("模板中未发现 {{占位符}}，将原样复制生成")

        planned, replaced_total = [], 0
        for i, rec in enumerate(records, start=1):
            idx = idx_offset + i
            fname = build_out_name(args.out_name, rec, idx)
            out_path = out_dir / fname
            planned.append((idx, rec, out_path))

        if args.dry_run:
            relative = [str(p.relative_to(root)) for _, _, p in planned]
            result.stats = {"records": len(planned), "dry_run": True, "written": 0,
                            "mode": args.mode, "output_dir": str(out_dir.relative_to(root)),
                            "preview_files": relative}
            result.warnings.append("dry-run：未写入任何文件")
            _emit(result, args.json)
            return 0

        out_dir.mkdir(parents=True, exist_ok=True)

        LOGGER = setup_logger(Path(args.root) / args.log if args.log else None, args.verbose)
        LOGGER.info("批量填充开始：模板=%s 数据=%s 记录数=%d 模式=%s",
                    tpl.name, data.name, len(planned), args.mode)

        for idx, rec, out_path in planned:
            log_record_summary(idx, rec)
            if out_path.exists() and not args.overwrite:
                result.warnings.append(f"已存在且未加 --overwrite，跳过：{out_path.name}")
                continue
            try:
                n, missing = fill_document(tpl, rec, out_path, args.mode,
                                           default_map, args.missing_mark)
                replaced_total += n
                result.output_files.append(str(out_path.relative_to(root)))
                if missing:
                    result.missing_fields[out_path.name] = sorted(missing)
                    result.warnings.append(f"{out_path.name}：{len(missing)} 个字段缺失已按 "
                                           f"{args.mode} 处理")
            except TemplateFillError as e:
                result.failed.append({"row": idx, "file": out_path.name, "error": str(e)})
                result.warnings.append(f"第 {idx} 条生成失败：{e}")

        result.stats = {"records": len(planned), "generated": len(result.output_files),
                        "failed": len(result.failed), "placeholders_replaced": replaced_total,
                        "mode": args.mode}
        result.success = not result.failed

    except TemplateFillError as e:
        result.success = False
        result.failed.append({"error": str(e)})
    except json.JSONDecodeError as e:
        result.success = False
        result.failed.append({"error": f"--default-map 不是合法 JSON：{e}"})
    except Exception as e:  # 兜底，避免把栈抛给智能体
        result.success = False
        result.failed.append({"error": f"未预期错误：{type(e).__name__}: {e}"})

    _emit(result, args.json)
    return 0 if result.success else 1


def _emit(result: FillResult, as_json: bool) -> None:
    if as_json:
        # 低 Token：只回路径、统计与警告，不回文档正文
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        return
    print("=== 填充结果 ===")
    print(f"成功：{result.success}")
    preview = result.stats.get("preview_files") if result.stats.get("dry_run") else None
    if preview:
        print(f"[预览] 将生成 {len(preview)} 个文件（未写入磁盘）：")
        for p in preview[:10]:
            print(f"  {p}")
        if len(preview) > 10:
            print(f"  ...共 {len(preview)} 个")
    for f in result.output_files:
        print(f"  已生成：{f}")
    for w in result.warnings:
        print(f"  [警告] {w}")
    for f in result.failed:
        print(f"  [失败] {f}")
    if result.stats:
        print(f"统计：{json.dumps(result.stats, ensure_ascii=False)}")


if __name__ == "__main__":
    raise SystemExit(main())
