#!/usr/bin/env python3
"""validate_data.py —— 意图 3 + 可选功能：填充前的数据完整性体检。

用法：
    python skills/scripts/validate_data.py --template templates/合同模板.docx --data data/员工.xlsx
    python skills/scripts/validate_data.py --template templates/合同模板.docx --data data/员工.xlsx --json
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from wt_core import (  # noqa: E402
    LOOP_OPEN_RE, PLACEHOLDER_RE, resolve_in_workspace, scan_template,
    setup_logger, TemplateFillError,
)
from wt_data import hydrate_all, load_records, missing_fields_of  # noqa: E402


def check(template_path: Path, records: list[dict]) -> dict:
    info = scan_template(template_path)
    tpl_fields = {f["field"] for f in info["fields"]}
    loop_names = {l["name"] for l in info["loops"]}
    loop_fields = set(info["loop_fields"])

    # 循环区字段由明细行逐条校验，不参与主记录校验
    main_fields = sorted(tpl_fields - loop_fields - loop_names)

    field_miss = Counter()
    rows_with_missing = []
    extra_counter = Counter()
    loop_issues = []

    for i, rec in enumerate(records, start=1):
        miss = [f for f in main_fields if f not in rec or rec.get(f) is None]
        for f in miss:
            field_miss[f] += 1
        if miss:
            rows_with_missing.append({"row": i, "missing": miss})

        extra = [k for k in rec if k not in tpl_fields and k not in loop_names]
        for k in extra:
            extra_counter[k] += 1

        # 循环区：数据缺失或不是列表
        for ln in loop_names:
            val = rec.get(ln)
            if val is None:
                loop_issues.append({"row": i, "loop": ln, "issue": "明细数据缺失"})
            elif not isinstance(val, list):
                loop_issues.append({"row": i, "loop": ln, "issue": "明细数据不是列表"})
            else:
                for j, item in enumerate(val, start=1):
                    if not isinstance(item, dict):
                        loop_issues.append({"row": i, "loop": ln, "issue": f"第{j}条明细不是对象"})
                        continue
                    for lf in loop_fields:
                        if lf not in item or item.get(lf) is None:
                            loop_issues.append({"row": i, "loop": ln,
                                                "issue": f"第{j}条明细缺字段 {lf}"})

    ok_rows = len(records) - len(rows_with_missing)
    return {
        "total_records": len(records),
        "ok_records": ok_rows,
        "rows_with_missing": rows_with_missing,
        "field_missing_stats": dict(field_miss.most_common()),
        "loop_issues": loop_issues,
        "unused_data_columns": dict(extra_counter.most_common()),
        "template_fields": main_fields,
        "loop_fields": sorted(loop_fields),
        "ready": ok_rows == len(records) and not loop_issues,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="填充前检查数据与模板字段的匹配情况")
    ap.add_argument("--template", required=True)
    ap.add_argument("--data", required=True, help="xlsx / json / csv")
    ap.add_argument("--sheet", default=None, help="Excel 工作表名，默认第一张")
    ap.add_argument("--root", default=".")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    setup_logger(verbose=args.verbose)
    try:
        root = Path(args.root).resolve()
        tpl = resolve_in_workspace(root, args.template)
        data = resolve_in_workspace(root, args.data)
        records = hydrate_all(load_records(data, args.sheet))
    except TemplateFillError as e:
        print(json.dumps({"success": False, "error": str(e)}, ensure_ascii=False))
        return 1

    if not records:
        print(json.dumps({"success": False, "error": "数据文件中没有有效记录"}, ensure_ascii=False))
        return 1

    report = check(tpl, records)

    if args.json:
        print(json.dumps({"success": True, **report}, ensure_ascii=False, indent=2))
        return 0

    print("=== 数据完整性体检 ===")
    print(f"记录总数：{report['total_records']}    完整：{report['ok_records']}    "
          f"缺字段：{len(report['rows_with_missing'])}")
    print(f"模板主字段（{len(report['template_fields'])}）：{', '.join(report['template_fields']) or '（无）'}")
    if report["loop_fields"]:
        print(f"循环明细字段：{', '.join(report['loop_fields'])}")

    if report["rows_with_missing"]:
        print("\n缺失明细：")
        for r in report["rows_with_missing"]:
            print(f"  第 {r['row']} 条：缺 {', '.join(r['missing'])}")
    if report["field_missing_stats"]:
        print("\n按字段统计缺失次数：")
        for f, c in report["field_missing_stats"].items():
            print(f"  {f}: {c} 条")

    if report["loop_issues"]:
        print("\n循环区问题：")
        for it in report["loop_issues"][:20]:
            print(f"  第 {it['row']} 条 / {it['loop']}: {it['issue']}")
    if report["unused_data_columns"]:
        print(f"\n数据中未被模板使用的列：{', '.join(report['unused_data_columns'])}")

    print("\n结论：" + ("数据完整，可以直接填充。" if report["ready"]
                       else "存在缺失，建议先选择处理策略（中止 / 占位 / 默认值）。"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
