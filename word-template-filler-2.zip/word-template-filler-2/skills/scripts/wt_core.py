"""
wt_core.py —— AI Word 模板填充核心引擎

职责：
  1. run 级占位符定位与回写（解决 Word 把 {{name}} 拆进多个 run 的静默失效问题）
  2. 遍历正文段落 / 表格单元格 / 页眉页脚 / 文本框
  3. 表格循环行 {{#items}}...{{/items}} 展开
  4. 缺失字段三策略：strict / lenient / default
  5. 路径白名单（防目录穿越）+ 模板注入防护（防数据被二次渲染）

设计原则：本模块纯确定性逻辑，不依赖任何大模型，可独立测试。
"""

from __future__ import annotations

import copy
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from docx import Document
from docx.table import Table, _Row

LOGGER = logging.getLogger("word_template_fill")

# ---------------------------------------------------------------- 常量与异常

PLACEHOLDER_RE = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")
LOOP_OPEN_RE = re.compile(r"\{\{\s*#(\w+)\s*\}\}")
LOOP_CLOSE_RE = re.compile(r"\{\{\s*/\w+\s*\}\}")

MISSING_MARK = "【待补充】"

# 引擎自动注入的字段（不需要用户数据提供）
AUTO_FIELDS = {"index", "序号", "_index"}

# 常见敏感字段：日志脱敏用
SENSITIVE_KEYS = {"身份证", "身份证号", "手机号", "电话", "银行卡", "password",
                  "密码", "api_key", "apikey", "token", "secret"}


class TemplateFillError(Exception):
    """模板填充过程中的业务异常基类。"""


class PathNotAllowedError(TemplateFillError):
    """路径不在白名单目录内（目录穿越 / 绝对路径逃逸）。"""


class MissingFieldError(TemplateFillError):
    """strict 模式下存在缺失字段。"""


class TemplateError(TemplateFillError):
    """模板本身有问题（无占位符、循环标记不配对等）。"""


# ---------------------------------------------------------------- 安全工具


def resolve_in_workspace(root: Path, target: str | Path) -> Path:
    """把路径解析到 root 之内，拒绝目录穿越与绝对路径逃逸。

    例：root=/proj，target="../../etc/passwd" -> PathNotAllowedError
    """
    root = Path(root).resolve()
    p = (root / Path(target)).resolve() if not Path(target).is_absolute() else Path(target).resolve()
    if p != root and root not in p.parents:
        raise PathNotAllowedError(f"路径越界（仅允许 {root} 之内）：{target}")
    return p


def escape_value(value: Any) -> str:
    """模板注入防护：数据中的 {{ }} 不允许被二次渲染。

    这是 Agent 场景下的"提示词/模板注入"变体——用户数据不应被当成模板指令。
    """
    s = "" if value is None else str(value)
    return s.replace("{{", "｛｛").replace("}}", "｝｝")


def mask_sensitive(key: str, value: Any) -> str:
    """日志脱敏：敏感字段只显示首尾。"""
    s = str(value)
    if key.strip().lower() in {k.lower() for k in SENSITIVE_KEYS} and len(s) > 6:
        return f"{s[:3]}{'*' * (len(s) - 6)}{s[-3:]}"
    return s


def log_record_summary(index: int, record: dict, max_items: int = 6) -> None:
    """记录一条数据的摘要，敏感字段自动脱敏后再入日志。"""
    parts = []
    for k, v in list(record.items())[:max_items]:
        if isinstance(v, (list, dict)):
            v = f"<{len(v)} 条明细>"
        parts.append(f"{k}={mask_sensitive(k, v)}")
    LOGGER.info("第 %d 条：%s", index, "，".join(parts))


def setup_logger(log_path: Path | None = None, verbose: bool = False) -> logging.Logger:
    LOGGER.setLevel(logging.DEBUG if verbose else logging.INFO)
    for h in list(LOGGER.handlers):
        LOGGER.removeHandler(h)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S")
    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(fmt)
        LOGGER.addHandler(fh)
    if verbose:
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        LOGGER.addHandler(sh)
    return LOGGER


# ---------------------------------------------------------------- 数据结构


@dataclass
class FillResult:
    """每次填充的结构化返回。注意：只回路径与统计，不回文档全文（低 Token）。"""
    success: bool
    output_files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    failed: list[dict] = field(default_factory=list)
    missing_fields: dict[str, list[str]] = field(default_factory=dict)
    stats: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "output_files": self.output_files,
            "warnings": self.warnings,
            "failed": self.failed,
            "missing_fields": self.missing_fields,
            "stats": self.stats,
        }


# ---------------------------------------------------------------- 核心：run 级替换


def _iter_block_paragraphs(container) -> Iterable:
    """取出容器（Document / _Cell / 页眉页脚）里的所有段落。"""
    yield from container.paragraphs
    for tbl in getattr(container, "tables", []):
        for row in tbl.rows:
            for cell in row.cells:
                yield from _iter_block_paragraphs(cell)


def _paragraph_containers(doc: Document) -> list:
    """正文 + 所有页眉页脚（含首页/奇偶页）。"""
    containers = [doc]
    try:
        for sec in doc.sections:
            for part in (sec.header, sec.footer,
                         sec.first_page_header, sec.first_page_footer,
                         sec.even_page_header, sec.even_page_footer):
                if part is not None:
                    containers.append(part)
    except Exception as e:  # 某些模板无 section 定义
        LOGGER.debug("读取页眉页脚失败：%s", e)
    return containers


def _replace_in_paragraph(paragraph, mapping: dict, missing_keys: set,
                          mode: str, missing_mark: str) -> int:
    """在单个段落内做 run 级替换，返回被替换的占位符数量。

    关键：先拼接所有 run 的文本建立 char -> (run_idx, offset) 映射，
    再反向（从后往前）替换，避免前面的改动打乱后面的索引。
    """
    runs = paragraph.runs
    if not runs:
        return 0

    texts = [r.text or "" for r in runs]
    full = "".join(texts)
    if "{{" not in full:
        return 0

    # 建立字符索引 -> (run 序号, 该 run 内偏移)
    owner: list[tuple[int, int]] = []
    for ri, t in enumerate(texts):
        for ci in range(len(t)):
            owner.append((ri, ci))

    hits = list(PLACEHOLDER_RE.finditer(full))
    if not hits:
        return 0

    count = 0
    for m in reversed(hits):  # 反向，索引不乱
        key = m.group(1).strip()
        start, end = m.span()
        if start >= len(owner) or end - 1 >= len(owner):
            continue

        if key in mapping:
            value = escape_value(mapping[key])
        else:
            missing_keys.add(key)
            if mode == "strict":
                continue  # strict 模式留给上层统一报错
            # default 模式的值已由 fill_document 合并进 mapping，这里统一用占位标记
            value = missing_mark

        ri_s, ci_s = owner[start]
        ri_e, ci_e = owner[end - 1]

        if ri_s == ri_e:
            # 占位符完整落在单个 run 内
            r = runs[ri_s]
            r.text = r.text[:ci_s] + value + r.text[ci_e + 1:]
        else:
            # 跨 run：值写入首个 run，其余 run 覆盖掉的片段清空
            runs[ri_s].text = runs[ri_s].text[:ci_s] + value
            for ri in range(ri_s + 1, ri_e):
                runs[ri].text = ""
            runs[ri_e].text = runs[ri_e].text[ci_e + 1:]
        count += 1

    return count


# ---------------------------------------------------------------- 核心：循环区展开


def _expand_loop_rows(table: Table, record: dict, mode: str,
                      missing_keys: set, missing_mark: str) -> int:
    """展开表格中的循环行。

    约定：某行任一单元格文本含 {{#items}}，则该行为循环模板行；
    用 deepcopy 复制该行（保留样式），逐条填值，再删除原模板行。
    """
    added = 0
    row_idx = 0
    while row_idx < len(table.rows):
        row = table.rows[row_idx]
        cell_texts = [c.text for c in row.cells]
        loop_key = None
        for ct in cell_texts:
            m = LOOP_OPEN_RE.search(ct)
            if m:
                loop_key = m.group(1)
                break

        if not loop_key:
            row_idx += 1
            continue

        data_rows = record.get(loop_key) if isinstance(record, dict) else record
        data_rows = data_rows or []
        if not isinstance(data_rows, list):
            raise TemplateError(f"循环字段 {loop_key} 的数据应为一列表（多条明细）")

        tmpl_row = row._tr
        parent = tmpl_row.getparent()
        insert_at = list(parent).index(tmpl_row)

        if not data_rows:
            # 无明细：删掉模板行，避免出现空行幽灵
            parent.remove(tmpl_row)
            continue

        for i, item in enumerate(data_rows):
            new_tr = copy.deepcopy(tmpl_row)
            parent.insert(insert_at + i, new_tr)
            wrapped = _Row(new_tr, table)
            mapping = drop_blanks(dict(item) if isinstance(item, dict)
                                  else {"value": item})
            mapping.setdefault("index", i + 1)
            for cell in wrapped.cells:
                for p in _iter_block_paragraphs(cell):
                    # 先清掉循环标记，再填值
                    _strip_loop_marks(p)
                    _replace_in_paragraph(p, mapping, missing_keys, mode, missing_mark)
            added += 1

        parent.remove(tmpl_row)
        row_idx += len(data_rows)
    return added


def _strip_loop_marks(paragraph) -> None:
    """去掉 {{#items}} / {{/items}} 这类控制标记（同样要 run 级处理）。"""
    for _ in range(4):
        text = "".join(r.text or "" for r in paragraph.runs)
        m = LOOP_OPEN_RE.search(text) or LOOP_CLOSE_RE.search(text)
        if not m:
            return
        _cut_span_across_runs(paragraph, m.span(), "")


def _cut_span_across_runs(paragraph, span: tuple[int, int], replacement: str) -> None:
    """把段落文本中 [start,end) 区间替换为 replacement，跨 run 安全。"""
    runs = paragraph.runs
    texts = [r.text or "" for r in runs]
    owner: list[tuple[int, int]] = []
    for ri, t in enumerate(texts):
        for ci in range(len(t)):
            owner.append((ri, ci))
    start, end = span
    if not owner or start >= len(owner) or end - 1 >= len(owner):
        return
    ri_s, ci_s = owner[start]
    ri_e, ci_e = owner[end - 1]
    if ri_s == ri_e:
        runs[ri_s].text = runs[ri_s].text[:ci_s] + replacement + runs[ri_s].text[ci_e + 1:]
    else:
        runs[ri_s].text = runs[ri_s].text[:ci_s] + replacement
        for ri in range(ri_s + 1, ri_e):
            runs[ri].text = ""
        runs[ri_e].text = runs[ri_e].text[ci_e + 1:]


# ---------------------------------------------------------------- 核心：整篇填充


def is_blank(v) -> bool:
    """空值判定：None 与空白字符串都算"未提供数据"。"""
    return v is None or (isinstance(v, str) and not v.strip())


def drop_blanks(mapping: dict) -> dict:
    """剔除空值，让"字段缺失"能被替换为占位标记而不是空串。"""
    return {k: v for k, v in mapping.items() if not is_blank(v)}


def fill_document(template_path: Path, record: dict, out_path: Path,
                  mode: str = "lenient", default_map: dict | None = None,
                  missing_mark: str = MISSING_MARK) -> tuple[int, set]:
    """把一条记录填入模板并保存。返回 (替换数量, 缺失字段集合)。"""
    doc = Document(str(template_path))
    mapping = drop_blanks(dict(record))
    if default_map:
        for k, v in drop_blanks(default_map).items():
            mapping.setdefault(k, v)

    missing: set = set()
    total = 0

    # 1) 表格循环行（必须在普通替换之前，否则明细行会被提前填坏）
    for container in _paragraph_containers(doc):
        for tbl in getattr(container, "tables", []):
            total += _expand_loop_rows(tbl, record, mode, missing, missing_mark)

    # 2) 普通占位符：正文 + 表格 + 页眉页脚 + 嵌套单元格
    for container in _paragraph_containers(doc):
        for p in _iter_block_paragraphs(container):
            total += _replace_in_paragraph(p, mapping, missing, mode, missing_mark)

    if mode == "strict" and missing:
        raise MissingFieldError("缺少字段：" + "、".join(sorted(missing)))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    LOGGER.info("生成 %s：替换 %d 处%s", out_path.name, total,
                f"，缺失字段 {sorted(missing)}" if missing else "")
    return total, missing


# ---------------------------------------------------------------- 模板扫描


def scan_template(template_path: Path) -> dict:
    """扫描模板里的占位符与循环区，供智能体"这个模板要填哪些字段"使用。"""
    doc = Document(str(template_path))
    fields: list[dict] = []
    loops: list[dict] = []
    seen, seen_loop = set(), set()

    for container in _paragraph_containers(doc):
        label = "正文"
        if container is not doc:
            label = "页眉页脚"
        for p in _iter_block_paragraphs(container):
            text = p.text or ""
            for m in LOOP_OPEN_RE.finditer(text):
                key = m.group(1)
                if key not in seen_loop:
                    seen_loop.add(key)
                    loops.append({"name": key, "location": label})
            for m in PLACEHOLDER_RE.finditer(text):
                raw = m.group(0)
                key = m.group(1).strip()
                if key.startswith("#") or key.startswith("/"):
                    continue
                if key not in seen:
                    seen.add(key)
                    fields.append({"field": key, "placeholder": raw, "location": label})

    # 标记哪些字段位于循环模板行内（这些字段由明细数据逐条提供）
    loop_fields: set = set()
    for container in _paragraph_containers(doc):
        for tbl in getattr(container, "tables", []):
            for row in tbl.rows:
                joined = " ".join(c.text for c in row.cells)
                if not LOOP_OPEN_RE.search(joined):
                    continue
                for pm in PLACEHOLDER_RE.finditer(joined):
                    k = pm.group(1).strip()
                    if not k.startswith(("#", "/")) and k not in AUTO_FIELDS:
                        loop_fields.add(k)

    for f in fields:
        f["in_loop"] = f["field"] in loop_fields or f["field"] in AUTO_FIELDS

    main_fields = [f for f in fields if not f["in_loop"]]

    return {
        "template": str(template_path),
        "fields": main_fields,
        "loops": loops,
        "loop_fields": sorted(loop_fields),
        "counts": {"fields": len(main_fields), "loops": len(loops),
                   "loop_fields": len(loop_fields)},
    }
