---
name: word_template_fill
description: 当用户要求用 Excel/JSON/CSV 等结构化数据批量填充 Word 模板、批量生成合同/协议/证明/通知书等 docx 文档时使用。支持先扫描模板字段、填充前数据体检、批量生成与单条补件。仅在用户明确要"生成 docx 文档"时使用；纯文档内容问答不要调用。
---

# Word 模板批量填充

把结构化数据（Excel/JSON/CSV）填入 `{{占位符}}` 形式的 Word 模板，批量生成 docx。
底层由 python-docx 完成，本 Skill 只负责编排 CLI 与组织参数。

## 目录结构与路径约定

本 Skill 采用 **SKILL.md 与执行脚本同目录** 的组织方式：

```
skills/
├── SKILL.md            # 本文件：能力声明，智能体读它决定何时调用
└── scripts/            # 具体执行脚本
    ├── inspect_template.py    # 意图1：扫描模板字段
    ├── validate_data.py       # 意图3：数据完整性体检
    ├── fill_template.py       # 意图2：批量填充生成
    ├── wt_core.py             # 核心引擎（run 级替换 / 循环区 / 安全策略）
    ├── wt_data.py             # 数据加载（xlsx / json / csv）
    └── make_samples.py        # 生成示例模板与测试数据
```

所有命令在**项目根目录**下执行，路径一律用相对路径：

```bash
cd /path/to/word-template-filler
python skills/scripts/<脚本> --root . --template ... --data ...
```

`--root .` 是安全边界，任何越出项目根目录的路径都会被拒绝。

## 三个能力（对应三类用户意图）

| 用户意图 | 脚本 | 说明 |
|---|---|---|
| "这个模板要填哪些字段？" | `inspect_template.py` | 扫描占位符与循环区 |
| "填充前看看数据缺不缺" | `validate_data.py` | 数据完整性体检（可选功能） |
| "用这份数据批量生成文档" | `fill_template.py` | 核心：单条/批量生成 |

## 参数

### inspect_template.py
| 参数 | 必填 | 说明 |
|---|---|---|
| `--template` | ✅ | docx 模板路径 |
| `--json` | | 输出 JSON（智能体一律加这个） |

### validate_data.py
| 参数 | 必填 | 说明 |
|---|---|---|
| `--template` `--data` | ✅ | 模板与数据文件 |
| `--sheet` | | Excel 工作表名，默认第一张 |

### fill_template.py
| 参数 | 必填 | 说明 |
|---|---|---|
| `--template` `--data` | ✅ | 模板与数据文件 |
| `--out` | | 输出目录，默认 `output` |
| `--out-name` | | 命名模板，如 `"{姓名}_实习协议.docx"` |
| `--row` | | 只处理第 N 条（1 开始），用于"只补某一条" |
| `--mode` | | `strict` 缺字段中止 / `lenient` 填【待补充】（默认）/ `default` 用默认值表 |
| `--default-map` | | `--mode default` 时的 JSON 映射或 .json 文件 |
| `--dry-run` | | **只预览不写盘**，生成前默认先跑一次 |
| `--overwrite` | | 允许覆盖同名文件，默认跳过 |
| `--sheet` | | Excel 工作表名 |

## 调用流程（务必按序）

1. **先扫描**（若不确定模板有哪些字段）
   `inspect_template.py --template <tpl> --json`
2. **先体检**（批量生成前强烈建议）
   `validate_data.py --template <tpl> --data <data> --json`
   有缺失 → **必须向用户确认策略**再继续，不要自作主张：
   - 中止该条 → `--mode strict`
   - 留占位待人工补 → `--mode lenient`
   - 用默认值 → `--mode default --default-map data/defaults.json`
3. **先预览**（生成文件前）
   `fill_template.py ... --dry-run --json`
   把将要生成的文件名列表报给用户（最多展示 10 个）。
4. **再执行**
   用户确认后去掉 `--dry-run` 正式生成。若输出目录已有同名文件，默认会跳过并给出警告；确需覆盖时再加 `--overwrite`（加之前应再次确认）。

## 返回格式（JSON）

```json
{
  "success": true,
  "output_files": ["output/张伟_实习协议.docx"],
  "warnings": ["李娜_实习协议.docx：3 个字段缺失已按 lenient 处理"],
  "failed": [],
  "missing_fields": {"李娜_实习协议.docx": ["岗位", "补贴标准"]},
  "stats": {"records": 4, "generated": 4, "failed": 0, "placeholders_replaced": 61}
}
```

**向用户汇报时只复述路径、数量和警告，不要把生成文档的完整内容念出来**（低 Token 要求）。
失败时 `success=false`，`failed[].error` 给出中文原因，直接转述给用户即可。

## 示例

### 示例 1：批量生成（最常见）

> 用户："用 实习生名单.xlsx 填 实习协议模板.docx，按 姓名_实习协议 命名，输出到 output"

```bash
python skills/scripts/validate_data.py --root . --template templates/实习协议模板.docx --data data/实习生名单.xlsx --json
python skills/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
  --data data/实习生名单.xlsx --out output --out-name "{姓名}_实习协议.docx" --dry-run --json
# 用户确认后：
python skills/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
  --data data/实习生名单.xlsx --out output --out-name "{姓名}_实习协议.docx" --json
```

### 示例 2：只给某一条补一份

> 用户："第 3 条记录之前没生成，帮我单独补一份"

```bash
python skills/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
  --data data/实习生名单.xlsx --out output --row 3 --out-name "{姓名}_实习协议.docx" --json
```

### 示例 3：字段很关键，不允许留空

> 用户："这份补贴数据不能缺，缺了就别生成"

```bash
python skills/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
  --data data/实习生名单.xlsx --out output --mode strict --json
```

## 模板语法（用户问"模板怎么写"时告知）

- 普通字段：`{{姓名}}`、`{{公司名称}}`
- 表格明细循环：在**模板行的任一单元格**写 `{{#items}}`，该行会按数据条数自动复制；循环内可用 `{{课程}}`、`{{课时}}` 等，以及自动序号 `{{index}}`
- Excel 中明细列写成 JSON 字符串：`[{"课程":"代码审计","课时":"10"}]`
- 页眉页脚、表格单元格里的占位符同样会被替换

## 错误处理

| 现象 | 原因 | 处理 |
|---|---|---|
| `路径越界` | 路径超出项目根目录 | 改用相对路径 |
| `缺少字段：XXX` | strict 模式下数据不全 | 补齐数据或改用 lenient/default |
| `暂不支持的数据格式` | 非 xlsx/json/csv | 转换格式 |
| `模板中未发现 {{占位符}}` | 占位符语法不对 | 检查是否用了 `{}` 单括号或中文括号 |
| 生成文件已存在被跳过 | 未加 `--overwrite` | 确认后加参数重跑 |

## 安全约束（不可绕过）

- 所有路径必须落在 `--root` 白名单内，目录穿越一律拒绝
- 数据中的 `{{ }}` 会被转义为全角，不会被当作模板指令二次渲染
- 覆盖已有文件、批量写盘前必须先预览并取得用户确认
- 日志不记录敏感字段明文；数据文件不得含真实敏感个人信息
- 全程离线执行，不联网、不执行 shell 命令
