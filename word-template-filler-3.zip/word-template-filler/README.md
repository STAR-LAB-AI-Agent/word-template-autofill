# AI Word 模板填充（智能体开发实战 · 04 题）

用自然语言驱动，把 Excel / JSON / CSV 中的结构化数据批量填入 Word 模板，生成可编辑的 docx 文档。

**技术路线**：用户自然语言 → 智能体(nanobot) → Skill(SKILL.md) → Python Script/CLI → python-docx → 结果

---

## 一、用户场景

> "用 实习生名单.xlsx 填 实习协议模板.docx，按 姓名_实习协议 命名，输出到 output"

典型用途：批量生成实习协议、录用通知、成绩证明、客户函件、报销单等制式文档。
原本需要人工逐个复制粘贴，现在一句话完成，且**缺失字段可被提前发现**，不会生成出带着空白的合同。

## 二、安装

```bash
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

要求 Python 3.10 ~ 3.12。

## 三、目录结构

```
word-template-filler/
├── skills/
│   └── word-template-filler/    # ← 一个自包含的 Skill（目录名 = 技能名）
│       ├── SKILL.md             # 智能体能力声明
│       └── scripts/
│           ├── wt_core.py           # 核心引擎：run 级替换 / 循环区 / 安全策略
│           ├── wt_data.py           # 数据加载：xlsx / json / csv
│           ├── inspect_template.py  # 意图1：扫描模板字段
│           ├── validate_data.py     # 意图3 + 可选功能：数据完整性体检
│           ├── fill_template.py     # 意图2：批量填充生成
│           ├── make_samples.py      # 生成示例模板与测试数据
│           ├── install_skill.py     # 一键安装到 nanobot
│           └── smoke_test.py        # CLI 冒烟验证（13 项）
│           └── check_env.py         # 环境自检
├── templates/               # Word 模板（{{占位符}}）
├── data/                    # 结构化数据
├── output/                  # 生成结果
├── tests/
│   ├── conftest.py          # 测试夹具（示例文件缺失时自动生成）
│   └── test_wt.py           # 16 个自动化测试
├── logs/                    # 运行日志（敏感字段已脱敏）
├── README.md                # 本文档
├── nanobot接入指南.md        # 接入步骤 + 工作目录配置详解
└── 答辩讲稿.md
```

> **目录说明**：`skills/word-template-filler/` 是一个**自包含单元**——能力声明（SKILL.md）
> 与它依赖的执行脚本同处一个目录，符合 nanobot 的 Skill 规范（目录名即技能名）。
> 整个目录可原样复制到任何 nanobot 的 skills 目录下，不会出现"换了机器找不到脚本"的路径依赖。

## 四、运行方法（可脱离智能体独立运行）

```bash
# 1) 这个模板要填哪些字段？
python skills/word-template-filler/scripts/inspect_template.py --root . --template templates/实习协议模板.docx

# 2) 填充前的数据完整性体检
python skills/word-template-filler/scripts/validate_data.py --root . --template templates/实习协议模板.docx \
       --data data/实习生名单.xlsx

# 3) 先预览（不写盘）
python skills/word-template-filler/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
       --data data/实习生名单.xlsx --out output --out-name "{姓名}_实习协议.docx" --dry-run

# 4) 正式生成
python skills/word-template-filler/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
       --data data/实习生名单.xlsx --out output --out-name "{姓名}_实习协议.docx"

# 只补第 3 条
python skills/word-template-filler/scripts/fill_template.py --root . --template templates/实习协议模板.docx \
       --data data/实习生名单.xlsx --out output --row 3
```

加 `--json` 输出结构化 JSON（智能体调用时使用）；加 `-v` 打印详细日志。

### 缺失字段三策略

| 模式 | 行为 | 适用 |
|---|---|---|
| `--mode lenient`（默认） | 填 `【待补充】` 并给出警告 | 一般场景 |
| `--mode strict` | 该条中止生成并报错，其余继续 | 金额、证件号等关键字段 |
| `--mode default --default-map data/defaults.json` | 用默认值表兜底 | 有常规兜底值的字段 |

## 五、模板语法

| 语法 | 说明 |
|---|---|
| `{{姓名}}` | 普通字段，正文/表格/页眉页脚均可 |
| `{{#items}}` | 写在**表格模板行的任一单元格**，该行按数据条数自动复制 |
| `{{课程}}` `{{课时}}` | 循环行内的字段 |
| `{{index}}` | 自动序号，无需在数据里提供 |

Excel 中明细列写成 JSON 字符串即可：
`[{"课程":"代码审计","课时":"10","授课方式":"线下"}]`

## 六、接入 nanobot

本 Skill 采用 `SKILL.md + Python Script/CLI` 的轻量集成，**不开发 MCP Server**。

### 6.1 nanobot 的 Skill 规范

nanobot 从两个位置加载 Skill，**workspace 优先级更高**（同名可覆盖内置）：

```
~/.nanobot/workspace/skills/<skill-name>/SKILL.md   ← 用户自定义（推荐）
<nanobot 源码>/nanobot/skills/<skill-name>/SKILL.md ← 内置
```

**目录名即技能名**，必须与 SKILL.md 的 `name` 字段一致。本项目的 Skill 目录为
`skills/word-template-filler/`，已自包含 SKILL.md 与 scripts/，可直接整体复制。

### 6.2 一键安装（推荐）

```bash
python skills/word-template-filler/scripts/install_skill.py
```

脚本会自动探测 `~/.nanobot/workspace/skills`，把 Skill 复制过去。可选参数：

| 参数 | 说明 |
|---|---|
| `--target DIR` | 指定目标 skills 目录 |
| `--link` | 用软链接（改源码即时生效；Windows 需管理员权限，失败自动回退复制） |
| `--check` | 只检查环境，不安装 |

**手工安装**（等价操作）：把 `skills/word-template-filler/` 整个目录复制到
`~/.nanobot/workspace/skills/` 下即可。

### 6.3 关键：workspace 根目录 ⚠️

脚本用 `--root .` 限定安全边界，**这个 `.` 是 nanobot 的 workspace 根目录**。
因此需保证 workspace 根下有 `templates/`、`data/`、`output/`、`logs/`。

**推荐做法**：把本项目根目录 `word-template-filler/` 直接作为 nanobot 的 workspace
（在 nanobot 配置里设 `workspace` 指向它），这样所有路径天然对齐。

若 workspace 在别处，请把 `templates/`、`data/`、`output/`、`logs/` 一并放到 workspace 根下。

> **这是接入过程中最容易出错的一步**，90% 的"找不到模板""路径越界"都源于
> workspace 与项目根不一致。完整原理、Windows 操作步骤与排查表见
> **[`nanobot接入指南.md`](nanobot接入指南.md)**。

### 6.4 验证

**CLI 层**（不依赖 nanobot，任何时候都能跑）：

```bash
python skills/word-template-filler/scripts/smoke_test.py
```

一条命令跑完 13 项检查：扫描 → 体检 → 预览 → 生成 → **打开生成结果校验内容** →
安全拦截。全部通过会输出 `✅ 冒烟验证全部通过（13 项）`。
每次重新解压后建议先跑它。

**智能体层**：安装后**重启 nanobot 会话**（新 Skill 需重启才会被发现），然后说：

> "templates 里的 Word 模板需要填哪些字段？"

Agent 应读取 SKILL.md 并调用 `inspect_template.py`。若输出乱码或报编码错误，
在命令前加 `PYTHONIOENCODING=utf-8`。

### 6.5 触发机制说明

nanobot 采用**渐进式加载**：系统提示词里只包含所有 Skill 的 `name + description`
摘要；Agent 判断匹配后，才用 `read_file` 读取完整 SKILL.md，再按文档步骤调用 CLI。
因此 `description` 的措辞直接决定触发准确率——本项目已在 description 中写明了
"批量填充 Word 模板""生成合同/协议/证明"等触发场景与排除条件。

未使用 nanobot 时，任何其他支持 Skill/工具调用的智能体框架都可复用同一份 `SKILL.md`。

## 七、开源依赖与许可证

| 项目 | 版本 | 许可证 | 用途 |
|---|---|---|---|
| [python-docx](https://github.com/python-openxml/python-docx) | 1.2.0 | MIT | 读取/写入 docx，run 级文本操作、表格行复制 |
| [openpyxl](https://openpyxl.readthedocs.io/) | 3.1.5 | MIT | 读取 Excel 数据 |
| pytest | 8.x | MIT | 仅测试用 |

> **核心能力说明**：文档的解析、占位符替换、表格行复制与样式保留全部由 **python-docx** 提供，本项目不重复实现底层 OOXML 处理，只在其之上做占位符定位、循环展开与安全策略。

## 八、测试

```bash
python -m pytest tests/ -v
```

16 个用例，覆盖：拆 run 占位符替换、页眉替换、表格循环展开、空明细删除模板行、三档缺失策略、模板注入转义、路径穿越拦截、CLI 端到端、dry-run 不落盘、非 docx 模板拒绝、row 越界。

## 九、安全设计

| 措施 | 实现 |
|---|---|
| 目录白名单 | 所有路径 `resolve()` 后必须落在 `--root` 内，拦截 `../` 与绝对路径逃逸 |
| 模板注入防护 | 数据中的 `{{ }}` 转义为全角，不作为模板指令二次渲染 |
| 写操作确认 | 生成前默认 `--dry-run` 预览；同名文件默认跳过，需显式 `--overwrite` |
| 敏感信息保护 | 日志不记录敏感字段明文；不提交任何 API Key / 密码 |
| 最小权限 | 纯离线执行，不联网、不执行 shell 命令 |
| 异常兜底 | 业务异常分类捕获，JSON 返回中文原因，不向智能体抛栈 |

## 十、低 Token / 性能优化

1. **结构化返回**：CLI 只回文件路径、统计与警告，绝不把生成的文档正文塞回模型上下文。
2. **大文件不进模型**：Excel/JSON 的读取、筛选、字段匹配全部在 Python 侧完成，模型只见 `validate_data.py` 的汇总报告（缺了几条、缺哪些字段），而非整张表。
3. **批量一次调用**：N 条记录一次 CLI 调用完成，避免逐条交互导致的 N 倍往返。
4. **预览先行**：`--dry-run` 先确认命名与数量，避免生成错误文件后反复重试的 Token 浪费。

## 十一、已知问题

- 占位符暂不支持格式化（如 `{{金额:.2f}}`），需在数据源侧预先格式化。
- 循环区仅支持表格行，暂不支持段落级循环（如一段文字重复 N 遍）。
- 不支持在循环区内部再嵌套循环。
- 文本框（Text Box）内的占位符需通过 `w:txbxContent` 单独遍历，当前版本覆盖页眉页脚与表格，文本框支持在后续版本补齐。
- `.doc`（旧格式）需先另存为 `.docx`。
