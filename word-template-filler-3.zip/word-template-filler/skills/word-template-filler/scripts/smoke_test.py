#!/usr/bin/env python3
"""smoke_test.py —— 解压后的 CLI 冒烟验证（一条命令确认整条链路）。

它比 check_env.py 更进一步：不只是"能启动"，而是**真的跑一遍并校验生成结果的内容**。

检查项：
  1. inspect_template.py 能扫描出字段与循环区
  2. validate_data.py 能给出体检报告
  3. fill_template.py --dry-run 只预览、不落盘
  4. fill_template.py 正式生成，且生成文件真实存在
  5. 打开生成的 docx，确认占位符已被替换（无残留 {{ }}）
  6. 拆 run 的占位符被正确替换（验证核心难点）
  7. 表格循环区按数据条数展开
  8. 缺失字段按策略填入【待补充】
  9. 模板注入被转义（数据中 {{ }} 不二次渲染）
 10. 路径穿越被拦截

用法：
    python skills/word-template-filler/scripts/smoke_test.py
    python skills/word-template-filler/scripts/smoke_test.py --json   # 输出机器可读结果
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent  # -> 项目根
SCRIPTS = Path(__file__).resolve().parent
PLACEHOLDER_RE = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")

OK, FAIL, WARN = "[OK]  ", "[FAIL]", "[WARN]"
results: list[tuple[bool, str, str]] = []


def check(ok: bool, label: str, detail: str = "") -> bool:
    results.append((ok, label, detail))
    print(f"{(OK if ok else FAIL)} {label}" + (f"  -> {detail}" if detail else ""))
    return ok


def run_cli(script: str, *args: str, timeout: int = 180) -> dict:
    """运行 CLI 并解析 JSON；非 JSON 输出时用 raw 字段返回原文。"""
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = [sys.executable, "-X", "utf8", str(SCRIPTS / script),
           *(str(a) for a in args), "--json"]
    proc = subprocess.run(cmd, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=timeout)
    out = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
    err = (proc.stderr or b"").decode("utf-8", errors="replace").strip()
    try:
        data = json.loads(out) if out else {}
    except json.JSONDecodeError:
        data = {}
    data["_rc"] = proc.returncode
    data["_raw"] = out
    data["_err"] = err
    return data


def first(pattern: str) -> Path | None:
    files = sorted(ROOT.glob(pattern))
    return files[0] if files else None


def docx_text(path: Path) -> str:
    """取出 docx 全部文本（正文 + 页眉页脚 + 表格）。"""
    from docx import Document
    doc = Document(str(path))
    parts = [p.text for p in doc.paragraphs]
    try:
        for sec in doc.sections:
            for part in (sec.header, sec.footer):
                if part is not None:
                    parts += [p.text for p in part.paragraphs]
    except Exception:
        pass
    for tbl in doc.tables:
        for row in tbl.rows:
            parts += [c.text for c in row.cells]
    return "\n".join(parts)


def main() -> int:
    print("=" * 64)
    print("Word 模板填充 · CLI 冒烟验证")
    print(f"项目根目录：{ROOT}")
    print("=" * 64)

    # 0. 前置：示例文件
    tpl = first("templates/*.docx")
    dat = first("data/*.xlsx")
    if not check(tpl is not None, "找到 Word 模板",
                 tpl.name if tpl else "templates/ 下无 .docx，请先运行 make_samples.py"):
        return _finish()
    if not check(dat is not None, "找到数据文件",
                 dat.name if dat else "data/ 下无 .xlsx，请先运行 make_samples.py"):
        return _finish()
    tpl_rel = str(tpl.relative_to(ROOT))
    dat_rel = str(dat.relative_to(ROOT))

    out_dir = ROOT / "output"
    out_dir.mkdir(exist_ok=True)

    # 1. 扫描模板
    info = run_cli("inspect_template.py", "--root", ".", "--template", tpl_rel)
    fields = info.get("counts", {}).get("fields", 0)
    loops = info.get("counts", {}).get("loops", 0)
    if check(info.get("success") and fields > 0,
             "inspect_template.py 扫描成功",
             f"{fields} 个字段，{loops} 个循环区"):
        check(loops > 0, "识别到表格循环区", f"{loops} 个")
    else:
        print(f"       stderr: {info.get('_err', '')[:300]}")

    # 2. 数据体检
    rep = run_cli("validate_data.py", "--root", ".", "--template", tpl_rel,
                  "--data", dat_rel)
    check(rep.get("total_records", 0) > 0, "validate_data.py 体检可用",
          f"{rep.get('total_records', 0)} 条记录，完整 {rep.get('ok_records', 0)} 条")

    # 3. dry-run 不落盘
    marker = "SMOKE_DRY"
    for f in out_dir.glob(f"{marker}_*"):
        f.unlink()
    dry = run_cli("fill_template.py", "--root", ".", "--template", tpl_rel,
                  "--data", dat_rel, "--out", "output",
                  "--out-name", f"{marker}_{{姓名}}.docx", "--dry-run")
    dry_files = list(out_dir.glob(f"{marker}_*"))
    check(bool(dry.get("stats", {}).get("dry_run")) and not dry_files,
          "dry-run 只预览不落盘",
          f"预览 {len(dry.get('stats', {}).get('preview_files', []))} 个，实际写入 {len(dry_files)} 个")

    # 4. 正式生成
    prefix = "SMOKE"
    for f in out_dir.glob(f"{prefix}_*"):
        f.unlink()
    res = run_cli("fill_template.py", "--root", ".", "--template", tpl_rel,
                  "--data", dat_rel, "--out", "output",
                  "--out-name", f"{prefix}_{{姓名}}.docx", "--overwrite")
    generated = res.get("output_files", [])
    n_gen = res.get("stats", {}).get("generated", 0)
    if not check(n_gen > 0, "fill_template.py 批量生成成功",
                 f"生成 {n_gen} 个文件"):
        print(f"       stderr: {res.get('_err', '')[:300]}")
        return _finish()

    # 5~9. 打开生成的文件做内容校验
    docx_paths = [out_dir / Path(p).name for p in generated]
    docx_paths = [p for p in docx_paths if p.exists()]

    # 5. 无残留占位符（排除【待补充】场景由后续单独判）
    residual = []
    for p in docx_paths:
        left = PLACEHOLDER_RE.findall(docx_text(p))
        if left:
            residual.append((p.name, left[:3]))
    check(not residual, "生成的文档中无残留占位符",
          "" if not residual else f"{residual}")

    # 6. 拆 run 的占位符被替换（"公司名称" 在模板里是故意拆开的）
    joined = "\n".join(docx_text(p) for p in docx_paths)
    check("深空科技有限公司" in joined or "星环数据" in joined,
          "拆 run 的 {{公司名称}} 已正确替换",
          "验证了跨 run 占位符定位与回写")

    # 7. 表格循环展开：至少有一个文档表格行数 > 1
    from docx import Document
    max_rows = 0
    for p in docx_paths:
        try:
            for t in Document(str(p)).tables:
                max_rows = max(max_rows, len(t.rows))
        except Exception:
            pass
    check(max_rows > 1, "表格循环区已展开", f"最大表格行数 {max_rows}（含表头）")

    # 8. 缺失字段 -> 【待补充】
    check("【待补充】" in joined, "缺失字段填入【待补充】",
          "lenient 策略生效") if "【待补充】" in joined else check(
        True, "缺失字段处理", "本批数据无缺失，未触发占位（可构造缺失数据验证）")

    # 9. 模板注入被转义（全角）
    check("｛｛" in joined, "模板注入被转义（数据中的 {{ 未二次渲染）",
          "出现全角 ｛｛ 即拦截成功") if "｛｛" in joined else check(
        True, "模板注入防护", "本批数据无注入样本，未触发")

    # 10. 路径穿越被拦截
    trav = run_cli("fill_template.py", "--root", ".", "--template", tpl_rel,
                   "--data", "../../../etc/passwd", "--out", "output")
    check(trav.get("success") is False and "路径越界" in json.dumps(
        trav.get("failed", []), ensure_ascii=False),
        "路径穿越被拦截", "越界访问已拒绝")

    # 清理本次生成的临时文件
    for f in out_dir.glob(f"{prefix}_*"):
        f.unlink()
    for f in out_dir.glob(f"{marker}_*"):
        f.unlink()

    return _finish()


def _finish() -> int:
    failed = [r for r in results if not r[0]]
    print("\n" + "=" * 64)
    if failed:
        print(f"冒烟验证未通过：{len(failed)}/{len(results)} 项失败")
        for _, label, detail in failed:
            print(f"  - {label}  {detail}")
        print("\n排查建议：")
        print("  1) 确认在项目根目录执行（本文件所在目录的 4 层上级）")
        print("  2) pip install -r requirements.txt")
        print("  3) python skills/word-template-filler/scripts/make_samples.py 重建示例")
        print("  4) python skills/word-template-filler/scripts/check_env.py 检查环境")
        print("=" * 64)
        return 1
    print(f"✅ 冒烟验证全部通过（{len(results)} 项）")
    print("CLI 链路完全正常：扫描 → 体检 → 预览 → 生成 → 内容校验 → 安全拦截")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
