#!/usr/bin/env python3
"""install_skill.py —— 把本 Skill 安装到 nanobot。

nanobot 从两个位置加载 Skill（workspace 优先级更高）：
    ~/.nanobot/workspace/skills/<skill-name>/SKILL.md    ← 用户自定义（推荐）
    <nanobot 源码>/nanobot/skills/<skill-name>/SKILL.md  ← 内置

用法：
    python skills/word-template-filler/scripts/install_skill.py            # 安装（自动探测）
    python skills/word-template-filler/scripts/install_skill.py --target DIR
    python skills/word-template-filler/scripts/install_skill.py --link     # 软链（改代码即时生效）
    python skills/word-template-filler/scripts/install_skill.py --check    # 只检查不安装

安装后**重启 nanobot 会话**才会被发现。
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

SKILL_NAME = "word-template-filler"
ROOT = Path(__file__).resolve().parent.parent.parent.parent  # -> 项目根
SRC = ROOT / "skills" / SKILL_NAME


def default_targets() -> list[Path]:
    """按优先级返回候选安装位置。"""
    home = Path.home()
    return [
        home / ".nanobot" / "workspace" / "skills",   # nanobot 默认 workspace
        home / ".nanobot" / "skills",                 # 部分版本的备选路径
    ]


def probe_nanobot() -> str:
    """尝试确认 nanobot 是否安装。"""
    exe = shutil.which("nanobot")
    if not exe:
        return "未找到 nanobot 命令（若已用源码方式运行，忽略此提示）"
    try:
        r = subprocess.run([exe, "--version"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=30)
        return (r.stdout or r.stderr).strip().splitlines()[0]
    except Exception as e:
        return f"找到 nanobot 但无法获取版本：{e}"


def main() -> int:
    ap = argparse.ArgumentParser(description="安装 Word 模板填充 Skill 到 nanobot")
    ap.add_argument("--target", default=None,
                    help="目标 skills 目录（默认自动探测 ~/.nanobot/workspace/skills）")
    ap.add_argument("--link", action="store_true",
                    help="用软链接而非复制（改源码即时生效；Windows 需管理员权限）")
    ap.add_argument("--check", action="store_true", help="只检查环境，不安装")
    args = ap.parse_args()

    print("=" * 60)
    print("Word 模板填充 Skill · 安装到 nanobot")
    print("=" * 60)

    # 1. 校验源
    if not (SRC / "SKILL.md").exists():
        print(f"[FAIL] 找不到源 Skill：{SRC / 'SKILL.md'}")
        return 1
    if not (SRC / "scripts").is_dir():
        print(f"[FAIL] 找不到脚本目录：{SRC / 'scripts'}")
        return 1
    print(f"[OK]   源 Skill：{SRC}")

    # 2. nanobot 与依赖
    print(f"[INFO] nanobot：{probe_nanobot()}")
    try:
        import docx, openpyxl  # noqa: F401
        print("[OK]   依赖 python-docx / openpyxl 已安装")
    except ImportError as e:
        print(f"[WARN] 缺少依赖：{e}")
        print("       pip install -r requirements.txt -i "
              "https://pypi.tuna.tsinghua.edu.cn/simple")

    # 3. 确定目标
    if args.target:
        target = Path(args.target).expanduser().resolve()
    else:
        exist = [t for t in default_targets() if t.exists()]
        if not exist:
            target = default_targets()[0]
            print(f"[INFO] 未发现已有 skills 目录，将创建：{target}")
        else:
            target = exist[0]
            print(f"[OK]   发现 skills 目录：{target}")
    print(f"[INFO] 安装目标：{target / SKILL_NAME}")

    if args.check:
        print("\n（--check 模式，未执行安装）")
        return 0

    # 4. 安装
    try:
        target.mkdir(parents=True, exist_ok=True)
        dst = target / SKILL_NAME
        if dst.exists() or dst.is_symlink():
            print(f"[WARN] 已存在，先移除：{dst}")
            if dst.is_symlink() or dst.is_file():
                dst.unlink()
            else:
                shutil.rmtree(dst)

        if args.link:
            if platform.system() == "Windows":
                # Windows 需特权，失败则回退复制
                try:
                    os.symlink(SRC, dst, target_is_directory=True)
                    print(f"[OK]   软链接创建成功：{dst} -> {SRC}")
                except OSError as e:
                    print(f"[WARN] 软链接失败（Windows 需管理员权限）：{e}")
                    print("       回退为复制安装")
                    shutil.copytree(SRC, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
                    print(f"[OK]   已复制到：{dst}")
            else:
                os.symlink(SRC, dst, target_is_directory=True)
                print(f"[OK]   软链接创建成功：{dst} -> {SRC}")
        else:
            shutil.copytree(SRC, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
            print(f"[OK]   已复制到：{dst}")
    except Exception as e:
        print(f"[FAIL] 安装失败：{type(e).__name__}: {e}")
        return 1

    # 5. 后续提示
    print("\n" + "=" * 60)
    print("安装完成。请确认：")
    print("  1) 重启 nanobot 会话（新 Skill 需重启后才会被发现）")
    print(f"  2) workspace 根目录应为：{ROOT}")
    print("     即 templates/ data/ output/ 与 nanobot workspace 同级")
    print("     若 workspace 在别处，需把这几个目录一并放到 workspace 下")
    print("\n验证方式：对 nanobot 说")
    print('  "templates 里的 Word 模板需要填哪些字段？"')
    print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
