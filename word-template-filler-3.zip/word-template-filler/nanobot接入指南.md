# nanobot 接入指南（含工作目录配置详解）

> 本文是 `README.md` 第 6 节的展开版。
> **接入过程中 90% 的问题都出在"工作目录"上**，本文重点讲透这一点。

---

## 一、为什么"工作目录"是核心问题

### 1.1 脚本的安全边界是 `--root .`

本项目所有 CLI 都要求传 `--root .`：

```bash
python skills/word-template-filler/scripts/inspect_template.py --root . --template templates/xxx.docx
```

这个 `--root .` 是一个**安全白名单**：所有路径（模板、数据、输出）经过
`resolve()` 展开后，必须落在这个目录之内，否则报 `路径越界` 并拒绝访问
（这是防目录穿越的核心机制，详见 README 第九节）。

### 1.2 那么 `.` 到底是谁？

**`.` = 执行这条命令时的"当前工作目录"（Current Working Directory）。**

智能体通过 exec 工具执行脚本时，它的当前工作目录是 **nanobot 的 workspace**，
**不是**你项目所在的目录。

于是问题来了：

| 目录 | 位置 | 里面有你要的东西吗 |
|---|---|---|
| 你的项目根 | `C:\Users\hp\Desktop\...\word-template-filler` | ✅ 有 `templates/`、`data/` |
| nanobot workspace | `C:\Users\hp\.nanobot\workspace` | ❌ 默认没有 |

**两者不一致 → Agent 执行 `--root .` 时，`.` 指向 workspace →
`templates/xxx.docx` 解析到 workspace 下 → 文件不存在 → 报错。**

### 1.3 三种解法

| 方案 | 做法 | 优点 | 缺点 |
|---|---|---|---|
| **A（推荐）** | 把 workspace 指向项目根目录 | 单一数据源，改一处全生效 | 需改 config.json |
| B | 把 `templates/` `data/` 等复制到 workspace | 不动配置 | 两份数据，容易不同步 |
| C | 每次让 Agent 用绝对路径传 `--root` | 最灵活 | 依赖 Agent 理解，不稳定 |

**强烈推荐方案 A。**

---

## 二、方案 A：把 workspace 指向项目根（推荐）

### 2.1 确认你的项目根路径

项目根 = **同时包含下面这些的那一层**：

```
skills/  templates/  data/  output/  logs/  requirements.txt
```

在 PowerShell 里进入该目录，然后：

```powershell
echo %CD%
```

会打印完整路径，例如：

```
C:\Users\hp\Desktop\temp\word-template-filler\word-template-filler
```

> ⚠️ 注意：压缩包解压后常常**多套一层同名目录**，
> 请确保进到"能看到 skills/templates/data 的那一层"。
> 本文后续用 `<项目根>` 指代这个路径。

### 2.2 修改 config.json

配置文件位置：

```
Windows:  C:\Users\hp\.nanobot\config.json
Linux/Mac: ~/.nanobot/config.json
```

**不要手改**（JSON 少个逗号就整个崩），用脚本改最稳：

```powershell
python -c "
import json,io,os
p=os.path.expanduser('~/.nanobot/config.json')
c=json.load(io.open(p,encoding='utf-8'))
ws=r'<项目根>'
c.setdefault('agents',{}).setdefault('defaults',{})['workspace']=ws
io.open(p,'w',encoding='utf-8').write(json.dumps(c,ensure_ascii=False,indent=2))
print('workspace 已设为:', ws)
"
```

把 `<项目根>` 换成 2.1 得到的路径，例如：

```powershell
python -c "
import json,io,os
p=os.path.expanduser('~/.nanobot/config.json')
c=json.load(io.open(p,encoding='utf-8'))
ws=r'C:\Users\hp\Desktop\temp\word-template-filler\word-template-filler'
c.setdefault('agents',{}).setdefault('defaults',{})['workspace']=ws
io.open(p,'w',encoding='utf-8').write(json.dumps(c,ensure_ascii=False,indent=2))
print('workspace 已设为:', ws)
"
```

**确认写入成功**：

```powershell
python -c "
import json,io,os
c=json.load(io.open(os.path.expanduser('~/.nanobot/config.json'),encoding='utf-8'))
print(c['agents']['defaults'].get('workspace'))
"
```

打印出你的项目路径即成功。

> **备份习惯**：改之前先 `copy C:\Users\hp\.nanobot\config.json C:\Users\hp\.nanobot\config.json.bak`

### 2.3 重启 gateway

**配置是启动时读取的，改完必须重启，否则不生效。**

- 关掉正在跑 `nanobot webui` 的终端窗口（Ctrl+C 或直接关）
- 重新执行：

```powershell
nanobot webui
```

---

## 三、方案 B：复制数据目录到 workspace（备选）

如果方案 A 不生效，或你不想动配置：

```powershell
cd <项目根>
xcopy templates C:\Users\hp\.nanobot\workspace\templates\ /E /I /Y
xcopy data      C:\Users\hp\.nanobot\workspace\data\      /E /I /Y
mkdir C:\Users\hp\.nanobot\workspace\output
mkdir C:\Users\hp\.nanobot\workspace\logs
```

**缺点**：存在两份数据。你改了项目里的 `templates/`，workspace 里那份不会变，
容易调试时把自己绕晕。**调试完成后建议清理掉其中一份。**

---

## 四、如何验证工作目录是否配对

重启后，在 WebUI 或 CLI 里**直接问 Agent**：

> 执行 pwd，告诉我你当前的工作目录

或：

> 列出当前目录下有哪些文件夹

**正确结果**：返回的路径是你 2.1 里的项目根，且能看到
`skills`、`templates`、`data`、`output`、`logs`。

**错误结果**：返回 `C:\Users\hp\.nanobot\workspace`（或别的路径）
→ workspace 没生效，回到 2.2 检查。

---

## 五、完整接入流程（按顺序）

### 第 1 步：装 nanobot

```powershell
pip install nanobot-ai -i https://pypi.tuna.tsinghua.edu.cn/simple
nanobot --version
```

要求 Python ≥ 3.11。

### 第 2 步：初始化

```powershell
nanobot onboard
```

会创建 `~/.nanobot/config.json` 和 `~/.nanobot/workspace/`。

### 第 3 步：配置模型 API

编辑 `~/.nanobot/config.json`，在 `providers` 填你的 key，
在 `agents.defaults` 填 `model`（和 `provider`）。

各厂商 key 别混用——拿 A 家的 key 填进 B 家的 provider 一定报
`authentication_error`。

### 第 4 步：安装本 Skill

```powershell
cd <项目根>
python skills/word-template-filler/scripts/install_skill.py
```

若提示找不到 skills 目录，手动指定：

```powershell
python skills/word-template-filler/scripts/install_skill.py --target "C:\Users\hp\.nanobot\workspace\skills"
```

### 第 5 步：配置工作目录（← 本文重点）

按**第二节方案 A** 操作。

### 第 6 步：重启 + 验证

```powershell
nanobot webui
```

1. 左侧 **Skills** → 确认 `word-template-filler` 在列表里
2. 问 Agent "你的工作目录是什么" → 确认是项目根
3. 说"templates 里的 Word 模板需要填哪些字段？" → 应返回 12 个字段 + 1 个循环区

---

## 六、WebUI 模式特别说明

通过 `nanobot webui` 启动时，Agent 跑在 gateway 服务进程里，
**环境变量继承自启动它的那个终端**。

### 中文乱码 / UnicodeDecodeError

在**启动 webui 之前**，先在该终端执行：

```powershell
chcp 65001
$env:PYTHONIOENCODING="utf-8"
nanobot webui
```

**根治办法**：把模板和数据文件改成英文名（`template.docx` / `data.xlsx`），
ASCII 文件名不存在编码问题。

### 权限模式

WebUI 输入框附近有权限下拉，**选 `Full Access`**，
否则 exec 工具可能被限制，脚本跑不起来。

---

## 七、问题排查表

| 现象 | 原因 | 解决 |
|---|---|---|
| `路径越界（仅允许 ... 之内）` | workspace 与项目根不一致 | 第二节方案 A |
| `找不到模板` / PackageNotFoundError | 同上，或文件名乱码 | 方案 A + 改英文名 |
| Agent 不触发 Skill | description 未匹配 | 直接点名"用 word-template-filler 这个 skill" |
| Skills 列表里没有 | 没装 / 没重启 | 第 4 步 + 重启 gateway |
| `authentication_error` | key 错或 provider 不匹配 | 检查 config.json 的 providers |
| 中文乱码 | 终端编码 | 第六节，设 PYTHONIOENCODING |
| 装完改了代码没生效 | 复制安装，有两份 | 用 `install_skill.py --link` |

---

## 八、不依赖 nanobot 的验证方式

**本项目核心功能完全不依赖 nanobot。** 任何时候都可以先跑冒烟验证：

```powershell
python skills/word-template-filler/scripts/smoke_test.py
```

13 项检查，全部通过会输出：

```
✅ 冒烟验证全部通过（13 项）
```

这能帮你快速区分：**到底是我的脚本有问题，还是 nanobot 接入配置有问题。**

---

## 九、一句话记住

> **`--root .` 里的 `.`，是 Agent 执行时的工作目录，也就是 nanobot 的 workspace。
> 把 workspace 指向项目根，让 `templates/`、`data/` 落在它下面，一切就通了。**
